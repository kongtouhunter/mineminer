import subprocess
import os
import sys
import threading
import time

def start_miner(wallet):
    try:
        # 复制当前环境变量并设置钱包变量
        env = os.environ.copy()
        env['WALLET'] = wallet
        # 启动挖矿进程
        return subprocess.Popen(COMMAND, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env, text=True, encoding='utf-8', errors='ignore')
    except Exception as e:
        print(f"Error starting miner with wallet {wallet}: {e}")
        sys.exit(1)

def restart_miner(proc, wallet):
    try:
        # 终止当前进程
        proc.terminate()
        proc.wait()  # 等待进程终止
        # 启动新进程
        return start_miner(wallet)
    except Exception as e:
        print(f"Error restarting miner with wallet {wallet}: {e}")
        sys.exit(1)

def monitor_miner(wallet):
    proc = start_miner(wallet)
    last_restart_time = time.time()
    try:
        while True:
            # 设置非阻塞读取
            output = proc.stdout.readline()
            # 如果没有输出且进程已终止，重新启动进程
            if output == "" and proc.poll() is not None:
                proc = restart_miner(proc, wallet)
                last_restart_time = time.time()

            # 检测特定错误信息并重新启动矿工
            if "EInsufficientDifficulty" in output:
                proc = restart_miner(proc, wallet)
                last_restart_time = time.time()

            # 每隔1800秒重新启动矿工
            if time.time() - last_restart_time > 3600:
                proc = restart_miner(proc, wallet)
                last_restart_time = time.time()

            # 打印任何输出
            if output:
                print(output.strip())
    except Exception as e:
        print(f"Error monitoring miner with wallet {wallet}: {e}")
        sys.exit(1)

if __name__ == "__main__":
    # 设置命令
    COMMAND = ["./mineral-win.exe", "mine"]
    
    # 打印启动消息
    print("空投猎手社区专享，油管推特同名")

    # 获取用户输入的私钥
    wallet_keys = input("请输入私钥列表，用逗号分隔：").split(',')

    # 去除每个私钥的前后空白
    wallet_keys = [key.strip() for key in wallet_keys]

    # 为每个私钥启动一个新的线程来运行矿工进程
    threads = []
    for wallet in wallet_keys:
        t = threading.Thread(target=monitor_miner, args=(wallet,))
        threads.append(t)
        t.start()

    # 等待所有线程完成
    for t in threads:
        t.join()
