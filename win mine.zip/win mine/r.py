import subprocess
import os
import sys
import threading
import time

def start_miner(wallet):
    try:
        env = os.environ.copy()
        env['WALLET'] = wallet
        return subprocess.Popen(COMMAND, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env, text=True, encoding='utf-8', errors='ignore')
    except Exception as e:
        print(f"Error starting miner with wallet {wallet}: {e}")
        sys.exit(1)

def restart_miner(proc, wallet):
    try:
        proc.terminate()
        proc.wait()  
        return start_miner(wallet)
    except Exception as e:
        print(f"Error restarting miner with wallet {wallet}: {e}")
        sys.exit(1)

def monitor_miner(wallet):
    proc = start_miner(wallet)
    last_restart_time = time.time()
    try:
        while True:
            output = proc.stdout.readline()
            if  proc.poll() is not None:
                proc = restart_miner(proc, wallet)
                last_restart_time = time.time()

    
            if "EInsufficientDifficulty" in output:
                proc = restart_miner(proc, wallet)
                last_restart_time = time.time()

    
            if time.time() - last_restart_time > 3600:
                proc = restart_miner(proc, wallet)
                last_restart_time = time.time()

            # 打印任何输出
            if output:
                print(output.strip())
    except Exception as e:
        print(f"Error monitoring miner with wallet {wallet}: {e}")
        sys.exit(1)

if __name__ == "__main__":
    # 设置命令
    COMMAND = ["./mineral-win.exe", "mine"]
    
    # 打印启动消息
    print("空投猎手社区专享，油管推特同名")

    # 获取用户输入的私钥
    wallet_keys = input("请输入私钥列表，用逗号分隔：").split(',')


    wallet_keys = [key.strip() for key in wallet_keys]


    threads = []
    for wallet in wallet_keys:
        t = threading.Thread(target=monitor_miner, args=(wallet,))
        threads.append(t)
        t.start()

    # 等待所有线程完成
    for t in threads:
        t.join()
